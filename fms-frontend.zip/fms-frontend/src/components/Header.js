import React from 'react';
import './ProjectStyle.css';

const Header = () => (
  <header className="section__container header__container header__background">
    <h1 className="section__header">Find And Book<br />A Great Experience</h1>
  </header>
);

export default Header;
